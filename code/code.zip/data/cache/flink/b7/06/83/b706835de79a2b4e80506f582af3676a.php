<?php exit('dedecms');?>
a:2:{s:4:"data";a:1:{s:5:"reval";s:0:"";}s:7:"timeout";i:1415703718;}